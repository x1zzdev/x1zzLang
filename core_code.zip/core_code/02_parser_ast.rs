/*
==================================================
원본 파일
x1zz-compiler/src/parser.rs
x1zz-compiler/src/ast.rs

핵심 기능
재귀 하강 파서 (Recursive Descent Parser) — DSL 문장 → AST 변환

설명
x1zzLang DSL 소스코드를 렉서(Lexer)가 토큰 배열로 변환한 후,
이 파서가 재귀 하강 방식으로 파싱하여 Program AST를 생성한다.

파이프라인 구문 예시:
  v air = load("data.csv") :: AirQuality
      |> filter(col("pm10") > 30.0)
      |> groupBy("station")
      |> mean("pm10")
      |> orderBy("pm10", desc: true)

위 DSL이 아래 AST로 변환된다:
  Program {
    stmts: [
      Stmt::VarDecl {
        var_name: "air",
        source: PipelineSource::Load { file_path: "data.csv", schema_name: "AirQuality" },
        ops: [
          PipelineOp::Filter(Expr::BinOp { lhs: Ident("pm10"), op: Gt, rhs: FloatLit(30.0) }),
          PipelineOp::GroupBy("station"),
          PipelineOp::Mean("pm10"),
          PipelineOp::OrderBy { col: "pm10", desc: true },
        ],
      }
    ]
  }

파서 BNF 요약:
  program       = stmt* EOF
  stmt          = type_decl | var_stmt | expr_stmt
  type_decl     = "type" IDENT "=" "{" field_list "}" ";"?
  var_stmt      = "mut"? "v" IDENT "=" pipeline_expr ";"?
  pipeline_expr = (load_expr | var_ref) ("|>" pipeline_op)*
  load_expr     = "load" "(" STRING ")" "::" IDENT
  pipeline_op   = filter | select | groupBy | sum | mean | min | max
                | orderBy | take | dropNull | fillNull | join | withColumn | chart | cast | ...
  expr          = additive (cmp_op additive)?
  additive      = multiplicative (('+' | '-') multiplicative)*
  multiplicative = primary (('*' | '/') primary)*
  primary       = col("...") | IDENT | literals | "(" expr ")"
==================================================
*/

// ─────────────────────────────────────────────────────────────────────────────
// ── AST 노드 정의 (ast.rs에서 발췌) ──────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/// 표현식 노드 — DSL의 모든 값 표현을 담당
#[derive(Debug, Clone, PartialEq)]
pub enum Expr {
    Ident(String),      // 컬럼명 또는 변수 참조. filter에서 col("pm10") → Ident("pm10")
    StringLit(String),  // 문자열 리터럴  예: "서울"
    IntLit(i64),        // 정수 리터럴    예: 30
    FloatLit(f64),      // 부동소수 리터럴 예: 30.0
    BoolLit(bool),      // 불리언 리터럴  예: true / false
    BinOp {             // 이항 연산      예: col("pm10") > 30.0
        lhs: Box<Expr>,
        op:  BinOpKind,
        rhs: Box<Expr>,
    },
}

/// 이항 연산자 종류 — 비교 및 산술 연산 모두 포함
#[derive(Debug, Clone, PartialEq)]
pub enum BinOpKind {
    // 비교 연산자
    Eq, NotEq, Lt, Gt, LtEq, GtEq,
    // 산술 연산자 (withColumn 등 계산식에 사용)
    Add, Sub, Mul, Div,
}

/// 파이프라인 연산 스텝 — 각 |> 뒤에 오는 연산 하나
#[derive(Debug, Clone, PartialEq)]
pub enum PipelineOp {
    Filter(Expr),                                    // |> filter(expr)
    Select(Vec<String>),                             // |> select(["col1", "col2"])
    Count(Option<String>),                           // |> count  /  |> count("col")
    GroupBy(String),                                 // |> groupBy("col")
    Sum(String),                                     // |> sum("col")
    Mean(String),                                    // |> mean("col")
    Min(String),                                     // |> min("col")
    Max(String),                                     // |> max("col")
    OrderBy { col: String, desc: bool },             // |> orderBy("col", desc: true)
    Take(i64),                                       // |> take(10)
    DropNull(String),                                // |> dropNull("col")
    FillNull { col: String, value: FillNullValue },  // |> fillNull("col", 0)
    Join { other: String, left_on: Vec<String>, right_on: Vec<String>, how: JoinHow },
    WithColumn { name: String, expr: Expr },         // |> withColumn("new_col", expr)
    Chart(ChartConfig),                              // |> chart { type: bar, x: "col", y: "col" }
    Cast { col: String, to_type: String },           // |> cast("col", "float")
    Rename { old_name: String, new_name: String },   // |> rename("old", "new")
    Replace { col: String, from: String, to: String }, // |> replace("col", ".", "")
}

/// 파이프라인의 데이터 소스
#[derive(Debug, Clone, PartialEq)]
pub enum PipelineSource {
    Load { file_path: String, schema_name: String }, // load("path") :: Schema
    VarRef(String),                                  // 기존 변수 참조
}

/// 최상위 구문 노드 — 파일의 각 문장 한 개
#[derive(Debug, Clone, PartialEq)]
pub enum Stmt {
    TypeDecl { name: String, fields: Vec<StructField> },   // type Name = { ... }
    VarDecl { var_name: String, is_mut: bool, source: PipelineSource, ops: Vec<PipelineOp> },
    ExprStmt { source: PipelineSource, ops: Vec<PipelineOp> }, // 변수 저장 없이 실행
}

/// 컴파일 단위 — 파일 전체 AST 루트
#[derive(Debug, Clone, PartialEq)]
pub struct Program {
    pub stmts: Vec<Stmt>,
}

// ─────────────────────────────────────────────────────────────────────────────
// ── Parser 핵심 로직 (parser.rs에서 발췌) ─────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

pub struct Parser {
    tokens: Vec<Token>,
    pos: usize,
}

impl Parser {
    pub fn new(tokens: Vec<Token>) -> Self {
        Parser { tokens, pos: 0 }
    }

    // ── 최상위 진입점 ──────────────────────────────────────────────────────────
    /// 토큰 배열 전체를 파싱하여 Program AST를 생성한다.
    pub fn parse(&mut self) -> CompileResult<Program> {
        let mut program = Program::new();
        // EOF에 도달할 때까지 각 문장을 파싱하여 추가
        while !self.is_eof() {
            program.stmts.push(self.parse_stmt()?);
        }
        Ok(program)
    }

    // ── Stmt 문장 파싱 ─────────────────────────────────────────────────────────
    /// 현재 토큰을 보고 어떤 종류의 문장인지 판별하여 적절한 파서로 위임한다.
    fn parse_stmt(&mut self) -> CompileResult<Stmt> {
        match self.current_kind() {
            TokenKind::Type => self.parse_type_decl(),           // type Name = { ... }
            TokenKind::V | TokenKind::Mut => self.parse_var_stmt(), // (mut)? v name = ...
            TokenKind::Ident(_) if self.peek_pipeline() => {
                // ident |> op ... 형태의 표현식 문장 (결과를 변수에 저장하지 않음)
                self.parse_expr_stmt()
            }
            other => Err(CompileError::new(
                ErrorKind::UnexpectedToken(format!("{:?}", other)),
                self.current_span(),
                format!("구문 시작 불가 토큰: {:?}", other),
            )),
        }
    }

    // ── TypeDecl: type Name = { fields } ─────────────────────────────────────
    /// type AirQuality = { station: string, pm10: float, pm25: Option<float> }
    fn parse_type_decl(&mut self) -> CompileResult<Stmt> {
        self.expect(&TokenKind::Type)?;           // "type" 키워드 소비
        let name = self.expect_ident()?;          // 타입 이름
        self.expect(&TokenKind::Assign)?;         // "=" 소비
        self.expect(&TokenKind::LBrace)?;         // "{" 소비
        let fields = self.parse_field_list()?;    // 필드 목록 파싱
        self.expect(&TokenKind::RBrace)?;         // "}" 소비
        self.eat(&TokenKind::Semicolon);          // 선택적 ";" 소비
        Ok(Stmt::TypeDecl { name, fields })
    }

    /// 필드 목록 파싱: name: type, name: type, ...
    fn parse_field_list(&mut self) -> CompileResult<Vec<StructField>> {
        let mut fields = Vec::new();
        loop {
            if matches!(self.current_kind(), TokenKind::RBrace | TokenKind::Eof) {
                break; // "}" 또는 EOF면 필드 목록 종료
            }
            fields.push(self.parse_field()?);
            if !self.eat(&TokenKind::Comma) {
                break; // 쉼표가 없으면 종료
            }
        }
        Ok(fields)
    }

    /// 필드 한 개 파싱: name: Type 또는 name: Option<Type>
    fn parse_field(&mut self) -> CompileResult<StructField> {
        let name = self.expect_ident()?;
        self.expect(&TokenKind::Colon)?;
        let field_type = self.parse_type_name()?; // "string", "float", "Option<int>" 등
        Ok(StructField { name, field_type })
    }

    // ── VarDecl: (mut)? v name = pipeline_expr ───────────────────────────────
    /// v air = load("data.csv") :: AirQuality |> filter(...) |> mean(...)
    fn parse_var_stmt(&mut self) -> CompileResult<Stmt> {
        let is_mut = self.eat(&TokenKind::Mut);   // 선택적 "mut" 소비
        self.expect(&TokenKind::V)?;              // "v" 키워드
        let var_name = self.expect_ident()?;      // 변수명
        self.expect(&TokenKind::Assign)?;         // "="
        let (source, ops) = self.parse_pipeline_expr()?; // 파이프라인 표현식
        self.eat(&TokenKind::Semicolon);          // 선택적 ";"
        Ok(Stmt::VarDecl { var_name, is_mut, source, ops })
    }

    // ── 파이프라인 표현식 ─────────────────────────────────────────────────────
    /// (load_expr | var_ref) ("|>" pipeline_op)*
    ///
    /// 핵심 파싱 로직:
    ///   load("data.csv") :: AirQuality  |> filter(...) |> groupBy(...) |> mean(...)
    ///   ^────────────────────────────^  ^─────────────────────────────────────────^
    ///              source                              ops 체인
    fn parse_pipeline_expr(&mut self) -> CompileResult<(PipelineSource, Vec<PipelineOp>)> {
        // 소스 결정: load(...) 또는 기존 변수 참조
        let source = match self.current_kind() {
            TokenKind::Load => self.parse_load_source()?,
            TokenKind::Ident(name) => {
                let var_name = name.clone();
                self.advance();
                PipelineSource::VarRef(var_name)
            }
            other => {
                return Err(CompileError::new(
                    ErrorKind::UnexpectedToken(format!("{:?}", other)),
                    self.current_span(),
                    format!("파이프라인은 load(...) 또는 변수 참조로 시작해야 합니다."),
                ));
            }
        };

        // |> 연산자가 나오는 동안 계속 파이프라인 스텝을 파싱하여 ops에 누적
        let mut ops: Vec<PipelineOp> = Vec::new();
        while matches!(self.current_kind(), TokenKind::Pipeline) {
            self.advance(); // "|>" 토큰 소비
            ops.push(self.parse_pipeline_op()?); // 다음 연산 파싱
        }

        Ok((source, ops))
    }

    /// load("data.csv") :: SchemaName 파싱
    fn parse_load_source(&mut self) -> CompileResult<PipelineSource> {
        self.expect(&TokenKind::Load)?;      // "load" 키워드
        self.expect(&TokenKind::LParen)?;    // "("
        let file_path = match self.current_kind() {
            TokenKind::StringLit(s) => { self.advance(); s }
            other => {
                return Err(CompileError::new(
                    ErrorKind::ExpectedToken("StringLit".into()),
                    self.current_span(),
                    format!("load() 경로는 문자열 리터럴이어야 합니다. 실제: {:?}", other),
                ));
            }
        };
        self.expect(&TokenKind::RParen)?;    // ")"
        // "::" 타입 어노테이션 — 스키마 이름 지정: load("data.csv") :: AirQuality
        if !matches!(self.current_kind(), TokenKind::TypeAssign) {
            return Err(CompileError::new(
                ErrorKind::ExpectedToken("::".into()),
                self.current_span(),
                "'::' 뒤에는 스키마 이름이 와야 합니다. 예: load(\"data.csv\") :: AirQuality",
            ));
        }
        self.expect(&TokenKind::TypeAssign)?; // "::" 소비
        let schema_name = self.expect_ident()?;
        Ok(PipelineSource::Load { file_path, schema_name })
    }

    // ── PipelineOp 파싱 — 각 연산자별 파싱 로직 ─────────────────────────────
    /// |> 뒤에 오는 연산자를 토큰 종류에 따라 파싱한다.
    fn parse_pipeline_op(&mut self) -> CompileResult<PipelineOp> {
        match self.current_kind() {
            // filter(expr) — 표현식 기반 행 필터링
            TokenKind::Filter => {
                self.advance();
                self.expect(&TokenKind::LParen)?;
                let expr = self.parse_expr()?; // 조건식 파싱
                self.expect(&TokenKind::RParen)?;
                Ok(PipelineOp::Filter(expr))
            }
            // groupBy("col") — 집계의 기준 컬럼 설정
            // 이후 sum/mean/min/max 연산자와 쌍을 이루어 group_by().agg()로 변환됨
            TokenKind::GroupBy => {
                self.advance();
                self.expect(&TokenKind::LParen)?;
                let col_name = self.expect_string_lit()?;
                self.expect(&TokenKind::RParen)?;
                Ok(PipelineOp::GroupBy(col_name))
            }
            // mean("col") — 평균 집계
            TokenKind::Mean => {
                self.advance();
                self.expect(&TokenKind::LParen)?;
                let col_name = self.expect_string_lit()?;
                self.expect(&TokenKind::RParen)?;
                Ok(PipelineOp::Mean(col_name))
            }
            // sum("col") — 합계 집계
            TokenKind::Sum => {
                self.advance();
                self.expect(&TokenKind::LParen)?;
                let col_name = self.expect_string_lit()?;
                self.expect(&TokenKind::RParen)?;
                Ok(PipelineOp::Sum(col_name))
            }
            // orderBy("col", desc: true) — 정렬 (기본값: 오름차순)
            TokenKind::OrderBy => {
                self.advance();
                self.expect(&TokenKind::LParen)?;
                let col_name = self.expect_string_lit()?;
                // 선택적 desc: true/false 파싱
                let desc = if matches!(self.current_kind(), TokenKind::Comma) {
                    self.advance();
                    self.expect(&TokenKind::Desc)?;
                    self.expect(&TokenKind::Colon)?;
                    match self.current_kind() {
                        TokenKind::True  => { self.advance(); true  }
                        TokenKind::False => { self.advance(); false }
                        other => return Err(CompileError::new(
                            ErrorKind::ExpectedToken("true or false".into()),
                            self.current_span(),
                            format!("desc: 뒤에는 true 또는 false. 실제: {:?}", other),
                        )),
                    }
                } else {
                    false // desc 미지정 시 기본값: 오름차순
                };
                self.expect(&TokenKind::RParen)?;
                Ok(PipelineOp::OrderBy { col: col_name, desc })
            }
            // take(n) — 상위 n행 슬라이싱
            TokenKind::Take => {
                self.advance();
                self.expect(&TokenKind::LParen)?;
                let n = match self.current_kind() {
                    TokenKind::IntLit(n) => { self.advance(); n }
                    other => return Err(CompileError::new(
                        ErrorKind::ExpectedToken("IntLit".into()),
                        self.current_span(),
                        format!("take() 에는 정수 리터럴. 실제: {:?}", other),
                    )),
                };
                self.expect(&TokenKind::RParen)?;
                Ok(PipelineOp::Take(n))
            }
            // join(other_var, on: "key") 또는 join(other_var, left_on: "a", right_on: "b")
            TokenKind::Join => {
                self.advance();
                self.expect(&TokenKind::LParen)?;
                let other = self.expect_ident()?;       // 조인 대상 변수명
                self.expect(&TokenKind::Comma)?;
                // on:, left_on:, right_on:, how: 등 명명 인수 루프
                let mut on_keys: Vec<String> = Vec::new();
                let mut left_on_keys: Vec<String> = Vec::new();
                let mut right_on_keys: Vec<String> = Vec::new();
                let mut how = JoinHow::Inner;  // 기본값: inner join
                loop {
                    if matches!(self.current_kind(), TokenKind::RParen | TokenKind::Eof) { break; }
                    match self.current_kind() {
                        TokenKind::On => {
                            self.advance();
                            self.expect(&TokenKind::Colon)?;
                            on_keys = vec![self.expect_string_lit()?];
                        }
                        TokenKind::LeftOn => {
                            self.advance();
                            self.expect(&TokenKind::Colon)?;
                            left_on_keys = vec![self.expect_string_lit()?];
                        }
                        TokenKind::RightOn => {
                            self.advance();
                            self.expect(&TokenKind::Colon)?;
                            right_on_keys = vec![self.expect_string_lit()?];
                        }
                        TokenKind::How => {
                            self.advance();
                            self.expect(&TokenKind::Colon)?;
                            let how_str = self.expect_string_lit()?;
                            how = JoinHow::from_str(&how_str).unwrap_or(JoinHow::Inner);
                        }
                        _ => break,
                    }
                    self.eat(&TokenKind::Comma);
                }
                let (final_left, final_right) = if !left_on_keys.is_empty() {
                    (left_on_keys, right_on_keys)
                } else {
                    (on_keys.clone(), on_keys)
                };
                self.expect(&TokenKind::RParen)?;
                Ok(PipelineOp::Join { other, left_on: final_left, right_on: final_right, how })
            }

            // 나머지 연산자: select, count, min, max, dropNull, fillNull, withColumn, chart, cast, rename, replace
            // → 동일한 패턴으로 파싱됨 (실제 전체 구현은 parser.rs 참고)
            other => Err(CompileError::new(
                ErrorKind::UnexpectedToken(format!("{:?}", other)),
                self.current_span(),
                format!("|> 다음에 유효한 연산자가 필요합니다. 실제: {:?}", other),
            )),
        }
    }

    // ── 표현식 파서 — 연산자 우선순위 계층 ───────────────────────────────────
    //
    // 우선순위 (낮음 → 높음):
    //   1. 비교 연산자: == != < > <= >=   (parse_expr)
    //   2. 덧셈/뺄셈:  + -               (parse_additive)
    //   3. 곱셈/나눗셈: * /              (parse_multiplicative)
    //   4. 기본 값:  col(), 리터럴, 변수  (parse_primary)

    /// 최상위 표현식 파싱: additive (비교연산자 additive)?
    fn parse_expr(&mut self) -> CompileResult<Expr> {
        let lhs = self.parse_additive()?;
        // 비교 연산자가 있으면 이항 연산식으로 묶기
        if let Some(op) = self.current_cmp_op() {
            self.advance();
            let rhs = self.parse_additive()?;
            Ok(Expr::BinOp { lhs: Box::new(lhs), op, rhs: Box::new(rhs) })
        } else {
            Ok(lhs)
        }
    }

    /// 덧셈/뺄셈 파싱: multiplicative ((+ | -) multiplicative)*
    fn parse_additive(&mut self) -> CompileResult<Expr> {
        let mut lhs = self.parse_multiplicative()?;
        loop {
            let op = match self.current_kind() {
                TokenKind::Plus  => BinOpKind::Add,
                TokenKind::Minus => BinOpKind::Sub,
                _                => break,
            };
            self.advance();
            let rhs = self.parse_multiplicative()?;
            lhs = Expr::BinOp { lhs: Box::new(lhs), op, rhs: Box::new(rhs) };
        }
        Ok(lhs)
    }

    /// 곱셈/나눗셈 파싱: primary ((* | /) primary)*
    fn parse_multiplicative(&mut self) -> CompileResult<Expr> {
        let mut lhs = self.parse_primary()?;
        loop {
            let op = match self.current_kind() {
                TokenKind::Star  => BinOpKind::Mul,
                TokenKind::Slash => BinOpKind::Div,
                _                => break,
            };
            self.advance();
            let rhs = self.parse_primary()?;
            lhs = Expr::BinOp { lhs: Box::new(lhs), op, rhs: Box::new(rhs) };
        }
        Ok(lhs)
    }

    /// 기본 값(primary) 파싱:
    ///   col("name") → Expr::Ident("name")
    ///   IDENT       → Expr::Ident
    ///   숫자/문자열/불리언 리터럴
    ///   "(" expr ")" 괄호식
    fn parse_primary(&mut self) -> CompileResult<Expr> {
        match self.current_kind() {
            TokenKind::Ident(s) => {
                self.advance();
                // col("column_name") 함수 호출 형태 처리
                // col("pm10") → Expr::Ident("pm10") — 런타임에서 polars::col("pm10") 로 변환
                if s == "col" && matches!(self.current_kind(), TokenKind::LParen) {
                    self.advance(); // "(" 소비
                    let col_name = match self.current_kind() {
                        TokenKind::StringLit(name) => { self.advance(); name }
                        other => return Err(CompileError::new(
                            ErrorKind::ExpectedToken("StringLit".into()),
                            self.current_span(),
                            format!("col() 안에는 문자열 리터럴. 실제: {:?}", other),
                        )),
                    };
                    self.expect(&TokenKind::RParen)?; // ")" 소비
                    Ok(Expr::Ident(col_name))
                } else {
                    Ok(Expr::Ident(s))
                }
            }
            TokenKind::IntLit(n)    => { let n = n; self.advance(); Ok(Expr::IntLit(n)) }
            TokenKind::FloatLit(f)  => { let f = f; self.advance(); Ok(Expr::FloatLit(f)) }
            TokenKind::StringLit(s) => { self.advance(); Ok(Expr::StringLit(s)) }
            TokenKind::True         => { self.advance(); Ok(Expr::BoolLit(true)) }
            TokenKind::False        => { self.advance(); Ok(Expr::BoolLit(false)) }
            TokenKind::LParen       => {
                self.advance(); // "(" 소비
                let expr = self.parse_expr()?;
                self.expect(&TokenKind::RParen)?;
                Ok(expr)
            }
            other => Err(CompileError::new(
                ErrorKind::UnexpectedToken(format!("{:?}", other)),
                self.current_span(),
                format!("표현식의 기본 값이 올 수 없는 토큰: {:?}", other),
            )),
        }
    }

    // 비교 연산자 토큰 → BinOpKind 변환
    fn current_cmp_op(&self) -> Option<BinOpKind> {
        match self.current_kind() {
            TokenKind::EqEq  => Some(BinOpKind::Eq),
            TokenKind::NotEq => Some(BinOpKind::NotEq),
            TokenKind::Lt    => Some(BinOpKind::Lt),
            TokenKind::Gt    => Some(BinOpKind::Gt),
            TokenKind::LtEq  => Some(BinOpKind::LtEq),
            TokenKind::GtEq  => Some(BinOpKind::GtEq),
            _                => None,
        }
    }

    // ── 내부 헬퍼 메서드 ──────────────────────────────────────────────────────
    fn current_kind(&self) -> TokenKind {
        self.tokens.get(self.pos).map(|t| t.kind.clone()).unwrap_or(TokenKind::Eof)
    }
    fn current_span(&self) -> Span {
        self.tokens.get(self.pos).map(|t| t.span.clone()).unwrap_or(Span::new(0, 0))
    }
    fn advance(&mut self) {
        if self.pos + 1 < self.tokens.len() { self.pos += 1; }
    }
    fn expect(&mut self, expected: &TokenKind) -> CompileResult<Span> {
        let kind = self.current_kind();
        let span = self.current_span();
        if kind == *expected { self.advance(); Ok(span) }
        else {
            Err(CompileError::new(
                ErrorKind::ExpectedToken(format!("{:?}", expected)),
                span.clone(),
                format!("예상 토큰 {:?}, 실제: {:?}", expected, kind),
            ))
        }
    }
    fn eat(&mut self, kind: &TokenKind) -> bool {
        if self.current_kind() == *kind { self.advance(); true } else { false }
    }
    fn is_eof(&self) -> bool {
        self.pos >= self.tokens.len().saturating_sub(1) || matches!(self.current_kind(), TokenKind::Eof)
    }
    /// 현재 Ident 토큰 바로 뒤에 |> 가 오는지 확인 (ExprStmt 판별용)
    fn peek_pipeline(&self) -> bool {
        self.pos + 1 < self.tokens.len()
            && matches!(self.tokens[self.pos + 1].kind, TokenKind::Pipeline)
    }
    fn parse_expr_stmt(&mut self) -> CompileResult<Stmt> {
        let (source, ops) = self.parse_pipeline_expr()?;
        self.eat(&TokenKind::Semicolon);
        Ok(Stmt::ExprStmt { source, ops })
    }
    fn expect_ident(&mut self) -> CompileResult<String> { todo!() }
    fn expect_string_lit(&mut self) -> CompileResult<String> { todo!() }
    fn parse_type_name(&mut self) -> CompileResult<String> { todo!() }
}

// 타입 더미 (컴파일 목적 — 실제 정의는 ast.rs, token.rs, error.rs에 있음)
struct StructField { name: String, field_type: String }
struct Token { kind: TokenKind, span: Span }
struct Span;
impl Span { fn new(_: usize, _: usize) -> Self { Span } fn clone(&self) -> Self { Span } }
#[derive(Debug, Clone, PartialEq)]
enum TokenKind { Type, V, Mut, Load, Filter, Select, Count, GroupBy, Sum, Mean, Min, Max, OrderBy, Take, DropNull, FillNull, Join, WithColumn, Chart, Cast, Rename, Replace, Ident(String), StringLit(String), IntLit(i64), FloatLit(f64), True, False, Assign, LParen, RParen, LBrace, RBrace, LBracket, RBracket, Colon, Comma, Semicolon, TypeAssign, Pipeline, Plus, Minus, Star, Slash, EqEq, NotEq, Lt, Gt, LtEq, GtEq, Desc, On, LeftOn, RightOn, How, OptionKw, Eof }
struct ChartConfig;
struct FillNullValue;
#[derive(Debug, Clone, PartialEq)]
enum JoinHow { Inner, Left, Outer, Cross }
impl JoinHow { fn from_str(_: &str) -> Option<Self> { None } }
impl Program { fn new() -> Self { Program { stmts: vec![] } } }
struct CompileError;
impl CompileError { fn new(_: ErrorKind, _: Span, _: impl Into<String>) -> Self { CompileError } }
enum ErrorKind { ExpectedToken(String), UnexpectedToken(String) }
type CompileResult<T> = Result<T, CompileError>;
