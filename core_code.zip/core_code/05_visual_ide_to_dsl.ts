/*
==================================================
원본 파일
C:\Users\LG\x1zz-lang-visual-ide\frontend\src\transpiler\x1zzTranspiler.js
C:\Users\LG\x1zz-lang-visual-ide\frontend\src\transpiler\dagWalker.js
C:\Users\LG\x1zz-lang-visual-ide\frontend\src\transpiler\nodeMappings.js

핵심 기능
Visual IDE → x1zzLang DSL 변환 (Transpiler)

설명
React Flow 기반의 비주얼 파이프라인 에디터에서
사용자가 드래그앤드롭으로 구성한 노드 DAG를
x1zzLang DSL 소스코드로 자동 변환한다.

변환 예시:
  비주얼 파이프라인:
    [fileInput: seoul_air_2026.csv]
           ↓
    [filter: pm10 > 30]
           ↓
    [groupBy: station]
           ↓
    [mean: pm10]
           ↓
    [chart: bar]

  생성되는 x1zzLang 코드:
    type Schema_fileInput = {
      측정소명: String,
      PM10농도: Float,
    }
    v fileInput = load("seoul_air_2026.csv") :: Schema_fileInput

    v result_fileInput = fileInput
      |> filter(col("PM10농도") > 30)
      |> groupBy("측정소명")
      |> mean("PM10농도")
      |> chart { type: "bar", x: "측정소명", y: "PM10농도" }

변환 파이프라인:
  React Flow nodes/edges
    → topologicalSort()    (Kahn 알고리즘 위상 정렬)
    → collectChain()       (루트 노드에서 BFS 체인 수집)
    → NODE_MAPPINGS[type]  (노드별 DSL 코드 생성 함수)
    → transpileToX1zz()    (최종 x1zzLang 코드 문자열 반환)
==================================================
*/

// ─────────────────────────────────────────────────────────────────────────────
// ── 타입 정의 (TypeScript) ───────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/** React Flow 노드 타입 */
interface FlowNode {
  id: string;
  type: string;
  data?: {
    label?: string;
    parameters?: Record<string, any>;
  };
}

/** React Flow 엣지 타입 */
interface FlowEdge {
  source: string;
  target: string;
}

/** 노드 변환 결과 타입 */
interface MappingResult {
  type: 'source' | 'pipeline' | 'terminal';
  lines: string[];
  varName?: string;
}

/** 컬럼 스키마 항목 */
interface SchemaCol {
  name: string;
  type?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// ── dagWalker.js — DAG 탐색 및 위상 정렬 유틸리티 ────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/**
 * in-degree가 0인 루트 노드를 찾는다.
 *
 * 루트 노드 = 어떤 엣지의 target도 아닌 노드 (진입 차수 0)
 * → fileInput 처럼 데이터 소스 역할을 하는 노드
 *
 * @param nodes  전체 노드 배열
 * @param edges  전체 엣지 배열
 * @returns      루트 노드 배열
 */
export function findRootNodes(nodes: FlowNode[], edges: FlowEdge[]): FlowNode[] {
  // 어떤 엣지의 target이 되는 노드 ID 집합 수집
  const targetIds = new Set(edges.map(e => e.target));
  // comment, container 노드는 파이프라인 외 요소이므로 제외
  return nodes.filter(n => !targetIds.has(n.id) && n.type !== 'comment' && n.type !== 'container');
}

/**
 * Kahn's 알고리즘으로 노드를 위상 정렬한다.
 *
 * 위상 정렬을 사용하는 이유:
 *   - 파이프라인의 실행 순서를 보장 (load → filter → groupBy → mean 순서 유지)
 *   - 순환 참조(사이클) 검출 가능
 *
 * Kahn's 알고리즘 단계:
 *   1. 각 노드의 in-degree(진입 차수) 계산
 *   2. in-degree=0인 노드를 큐에 추가
 *   3. 큐에서 노드를 꺼내 결과에 추가, 이웃 노드의 in-degree를 1 감소
 *   4. in-degree=0이 된 이웃 노드를 큐에 추가
 *   5. 큐가 빌 때까지 반복
 *
 * @param nodes  전체 노드 배열
 * @param edges  전체 엣지 배열
 * @returns      위상 정렬된 노드 배열
 */
export function topologicalSort(nodes: FlowNode[], edges: FlowEdge[]): FlowNode[] {
  const validNodes = nodes.filter(n => n.type !== 'comment' && n.type !== 'container');
  const nodeMap = new Map<string, FlowNode>(validNodes.map(n => [n.id, n]));

  // in-degree 초기화 (모든 노드 = 0)
  const inDegree = new Map<string, number>(validNodes.map(n => [n.id, 0]));
  // 인접 리스트 (source → target 목록)
  const adjacency = new Map<string, string[]>(validNodes.map(n => [n.id, []]));

  // 엣지를 순회하며 in-degree와 인접 리스트 구축
  edges.forEach(e => {
    if (nodeMap.has(e.source) && nodeMap.has(e.target)) {
      inDegree.set(e.target, (inDegree.get(e.target) || 0) + 1);
      adjacency.get(e.source)?.push(e.target);
    }
  });

  // in-degree 0인 노드를 큐에 추가 (실행 시작 가능 노드)
  const queue: string[] = [];
  inDegree.forEach((degree, nodeId) => {
    if (degree === 0) queue.push(nodeId);
  });

  const sorted: FlowNode[] = [];
  while (queue.length > 0) {
    const current = queue.shift()!;
    const node = nodeMap.get(current);
    if (node) sorted.push(node);

    // 현재 노드 처리 후 이웃 노드 in-degree 감소
    const neighbors = adjacency.get(current) || [];
    neighbors.forEach(neighborId => {
      const newDegree = (inDegree.get(neighborId) || 0) - 1;
      inDegree.set(neighborId, newDegree);
      if (newDegree === 0) queue.push(neighborId); // in-degree=0 되면 큐에 추가
    });
  }

  return sorted;
}

/**
 * 특정 루트 노드에서 BFS로 도달 가능한 모든 노드를 체인으로 수집한다.
 *
 * @param rootId      시작 노드 ID
 * @param sortedNodes 위상 정렬된 전체 노드 배열
 * @param edges       전체 엣지 배열
 * @returns           위상 정렬 순서를 유지한 도달 가능 노드 배열
 */
function collectChain(rootId: string, sortedNodes: FlowNode[], edges: FlowEdge[]): FlowNode[] {
  // BFS: rootId에서 도달 가능한 모든 노드 ID 수집
  const reachable = new Set<string>();
  const queue = [rootId];

  while (queue.length > 0) {
    const current = queue.shift()!;
    if (reachable.has(current)) continue;
    reachable.add(current);
    // 현재 노드가 source인 엣지의 target을 큐에 추가
    edges.filter(e => e.source === current).forEach(e => {
      if (!reachable.has(e.target)) queue.push(e.target);
    });
  }

  // 위상 정렬 순서를 유지하면서 도달 가능한 노드만 반환
  return sortedNodes.filter(n => reachable.has(n.id));
}

// ─────────────────────────────────────────────────────────────────────────────
// ── nodeMappings.js — 노드 타입별 DSL 코드 생성 함수 ─────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/** Python/Polars 타입 → x1zzLang 타입 변환 */
function mapTypeToX1zz(rawType: string): string {
  const t = (rawType || 'String').toLowerCase().replace(/\s+/g, '');
  if (t.includes('int'))                                   return 'Int';
  if (t.includes('float') || t.includes('double'))        return 'Float';
  if (t.includes('bool'))                                  return 'Bool';
  if (t.includes('datetime') || t.includes('timestamp'))  return 'DateTime';
  if (t.includes('date'))                                  return 'Date';
  if (t.includes('time'))                                  return 'Time';
  return 'String';
}

/** detectedSchema 배열 → x1zzLang type 블록 필드 문자열 생성 */
function buildSchemaFields(schema: SchemaCol[]): string {
  if (!schema || schema.length === 0) return '  _unknown: String';
  return schema
    .map(col => `  ${col.name}: ${mapTypeToX1zz(col.type || 'String')}`)
    .join(',\n');
}

/** 비교 연산자 → x1zzLang 연산자 변환 */
function mapOperator(op: string): string {
  const MAP: Record<string, string> = {
    '==': '==', '!=': '!=', '>': '>', '>=': '>=', '<': '<', '<=': '<='
  };
  return MAP[op] || '==';
}

/**
 * 값을 x1zzLang 리터럴로 변환
 *   - 숫자   → 그대로 (예: 30.5)
 *   - 불리언 → 그대로 (예: true)
 *   - 그 외  → "..." 문자열 리터럴
 */
function toLiteral(raw: unknown): string {
  if (raw === '' || raw === undefined || raw === null) return '""';
  const s = String(raw).trim();
  if (s === 'true' || s === 'false')     return s;
  if (/^-?[\d_]+(\.\d+)?$/.test(s))     return s;
  return `"${s}"`;
}

/**
 * 노드 타입별 x1zzLang 코드 생성 함수 맵.
 *
 * 반환 형식:
 *   { type: 'source'   }  → load 소스 (type 블록 + load 문)
 *   { type: 'pipeline' }  → |> 연산 체인 스텝
 *   { type: 'terminal' }  → 파이프라인 종단 (예: 출력)
 */
const NODE_MAPPINGS: Record<string, (node: FlowNode, varName: string, upstreamVarNames: string[]) => MappingResult> = {

  // ── fileInput — CSV 파일 로드 소스 노드 ────────────────────────────────────
  // 생성 예시:
  //   type Schema_fileInput = {
  //     측정소명: String,
  //     PM10농도: Float,
  //   }
  //   v fileInput = load("seoul_air_2026.csv") :: Schema_fileInput
  fileInput: (node, varName) => {
    const params     = node.data?.parameters || {};
    const filePath   = params.filePath || 'data.csv';
    const schema     = (params.detectedSchema || []) as SchemaCol[];
    const schemaName = `Schema_${varName}`;

    const typeBlock = `type ${schemaName} = {\n${buildSchemaFields(schema)}\n}`;
    const loadStmt  = `v ${varName} = load("${filePath}") :: ${schemaName}`;

    return { type: 'source', lines: [typeBlock, loadStmt], varName };
  },

  // ── filter — 조건식 기반 행 필터링 ────────────────────────────────────────
  // 생성 예시: |> filter(col("PM10농도") > 30)
  filter: (node) => {
    const params   = node.data?.parameters || {};
    const column   = params.column   || '_col';
    const operator = mapOperator(params.operator || '==');
    const value    = toLiteral(params.value ?? '');
    return {
      type: 'pipeline',
      lines: [`|> filter(col("${column}") ${operator} ${value})`],
    };
  },

  // ── select — 컬럼 선택 ────────────────────────────────────────────────────
  // 생성 예시: |> select(["station", "pm10", "pm25"])
  select: (node) => {
    const params   = node.data?.parameters || {};
    const columns  = (params.columns || []) as Array<string | { name: string; keep?: boolean }>;
    const colNames = columns
      .map(c => (typeof c === 'string' ? c : (c.keep !== false ? c.name : null)))
      .filter(Boolean)
      .map((n) => `"${n}"`)
      .join(', ');
    if (!colNames) {
      return { type: 'pipeline', lines: [`|> select([])  // 컬럼 미설정`] };
    }
    return { type: 'pipeline', lines: [`|> select([${colNames}])`] };
  },

  // ── groupBy — 기준 컬럼으로 그룹화 ───────────────────────────────────────
  // 생성 예시: |> groupBy("station")
  // 런타임에서 pending_group_by에 저장 후 다음 집계 연산과 쌍으로 처리된다
  groupBy: (node) => {
    const params = node.data?.parameters || {};
    const column = params.column || '_col';
    return { type: 'pipeline', lines: [`|> groupBy("${column}")`] };
  },

  // ── count — 행 수 또는 그룹별 카운트 ─────────────────────────────────────
  // 생성 예시: |> count  /  |> count("station")
  count: (node) => {
    const params = node.data?.parameters || {};
    const column = params.column as string | undefined;
    return {
      type: 'pipeline',
      lines: [column ? `|> count("${column}")` : `|> count`],
    };
  },

  // ── sum — 합계 집계 ───────────────────────────────────────────────────────
  // 생성 예시: |> sum("pm10")
  sum: (node) => {
    const params = node.data?.parameters || {};
    const column = params.column || '_col';
    return { type: 'pipeline', lines: [`|> sum("${column}")`] };
  },

  // ── mean — 평균 집계 ──────────────────────────────────────────────────────
  // 생성 예시: |> mean("pm10")
  mean: (node) => {
    const params = node.data?.parameters || {};
    const column = params.column || '_col';
    return { type: 'pipeline', lines: [`|> mean("${column}")`] };
  },

  // ── min / max ─────────────────────────────────────────────────────────────
  min: (node) => {
    const params = node.data?.parameters || {};
    const column = params.column || '_col';
    return { type: 'pipeline', lines: [`|> min("${column}")`] };
  },
  max: (node) => {
    const params = node.data?.parameters || {};
    const column = params.column || '_col';
    return { type: 'pipeline', lines: [`|> max("${column}")`] };
  },

  // ── sort (→ orderBy) ──────────────────────────────────────────────────────
  // 생성 예시: |> orderBy("pm10", desc: true)
  sort: (node) => {
    const params = node.data?.parameters || {};
    const column = params.column     || '_col';
    const desc   = params.descending === true ? 'true' : 'false';
    return { type: 'pipeline', lines: [`|> orderBy("${column}", desc: ${desc})`] };
  },

  // ── take — 상위 N행 슬라이싱 ─────────────────────────────────────────────
  // 생성 예시: |> take(10)
  take: (node) => {
    const params = node.data?.parameters || {};
    const n      = parseInt(String(params.count ?? params.n ?? 100), 10);
    const safeN  = isNaN(n) || n < 1 ? 100 : n;
    return { type: 'pipeline', lines: [`|> take(${safeN})`] };
  },

  // ── dropNull — null 값 있는 행 제거 ──────────────────────────────────────
  // 생성 예시: |> dropNull("pm10")
  dropNull: (node) => {
    const params = node.data?.parameters || {};
    const column = params.column || '_col';
    return { type: 'pipeline', lines: [`|> dropNull("${column}")`] };
  },

  // ── fillNull — null 값 채우기 ─────────────────────────────────────────────
  // 생성 예시: |> fillNull("pm10", 0.0)
  fillNull: (node) => {
    const params = node.data?.parameters || {};
    const column = params.column || '_col';
    const value  = toLiteral(params.value ?? 0);
    return { type: 'pipeline', lines: [`|> fillNull("${column}", ${value})`] };
  },

  // ── chart — 시각화 연산자 ─────────────────────────────────────────────────
  // 생성 예시: |> chart { type: "bar", x: "station", y: "pm10", title: "지역별 PM10" }
  // 런타임에서 ChartSpec JSON 생성 + Chart.js HTML 파일 자동 오픈
  chart: (node) => {
    const params    = node.data?.parameters || {};
    const chartType = params.chartType || 'bar';
    const x         = params.x         || '_col';
    const y         = params.y         || '_col';
    const title     = params.title     || '';
    const titlePart = title ? `, title: "${title}"` : '';
    return {
      type: 'pipeline',
      lines: [`|> chart { type: "${chartType}", x: "${x}", y: "${y}"${titlePart} }`],
    };
  },
};

/** 지원되지 않는 노드 타입의 폴백 처리 — 주석으로 표시 */
function getFallbackMapping(node: FlowNode): MappingResult {
  const typeName = node.type || 'unknown';
  return {
    type: 'pipeline',
    lines: [`// [${typeName}] 지원되지 않는 노드 타입 — 건너뜀`],
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// ── x1zzTranspiler.js — 메인 변환 함수 ──────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/** 변수명 생성: 노드 라벨 → 유효한 식별자 */
function makeVarName(node: FlowNode, index: number): string {
  const label = node.data?.label || node.type || 'data';
  const sanitized = label
    .replace(/[^a-zA-Z0-9_]/g, '_')  // 특수문자 → _
    .replace(/^(\d)/, '_$1')          // 숫자로 시작하면 _ 접두사
    .toLowerCase();
  return sanitized || `var_${index}`;
}

/** 중복 없는 고유 변수명 생성 */
function uniqueName(base: string, usedNames: Set<string>): string {
  let name = base;
  let counter = 2;
  while (usedNames.has(name)) {
    name = `${base}_${counter++}`;
  }
  usedNames.add(name);
  return name;
}

/**
 * 메인 변환 함수: nodes + edges → x1zzLang 소스코드
 *
 * 변환 전략:
 *   1. 주석/컨테이너 노드 제외
 *   2. Kahn 알고리즘으로 DAG 위상 정렬 → 실행 순서 결정
 *   3. 각 노드에 고유 변수명 부여
 *   4. 루트 노드(in-degree=0)를 찾아 각 파이프라인 체인 수집
 *   5. 노드타입 → NODE_MAPPINGS 함수로 x1zzLang 구문 생성
 *   6. source 노드 → type + load 블록 / pipeline 노드 → |> 체인으로 조합
 *   7. 최종 코드 문자열 반환
 *
 * @param nodes  React Flow 노드 배열
 * @param edges  React Flow 엣지 배열
 * @returns      x1zzLang DSL 소스 코드 문자열
 */
export function transpileToX1zz(nodes: FlowNode[], edges: FlowEdge[]): string {
  // 주석/컨테이너 노드 제외
  const validNodes = nodes.filter(n => n.type !== 'comment' && n.type !== 'container');
  const validEdges = edges.filter(e => {
    const srcExists = validNodes.some(n => n.id === e.source);
    const tgtExists = validNodes.some(n => n.id === e.target);
    return srcExists && tgtExists;
  });

  if (validNodes.length === 0) {
    return '// 캔버스에 노드가 없습니다.\n';
  }

  // 위상 정렬 — 실행 순서 보장
  const sortedNodes = topologicalSort(validNodes, validEdges);

  // 노드 ID → 변수명 맵 구축
  const nodeVarMap = new Map<string, string>();
  const usedNames  = new Set<string>();
  sortedNodes.forEach((node, idx) => {
    const base    = makeVarName(node, idx);
    const varName = uniqueName(base, usedNames);
    nodeVarMap.set(node.id, varName);
  });

  // 헤더 주석
  const lines: string[] = [];
  lines.push('// ============================================');
  lines.push('// Generated by x1zzLang Visual IDE Transpiler');
  lines.push(`// Nodes: ${validNodes.length}  |  Edges: ${validEdges.length}`);
  lines.push(`// Generated at: ${new Date().toISOString()}`);
  lines.push('// ============================================');
  lines.push('');

  // 루트 노드(in-degree=0)를 찾아 파이프라인 체인별로 코드 생성
  const rootNodes       = findRootNodes(validNodes, validEdges);
  const processedNodeIds = new Set<string>();

  rootNodes.forEach((rootNode, chainIdx) => {
    if (processedNodeIds.has(rootNode.id)) return;
    const chainVarName = nodeVarMap.get(rootNode.id) || `pipeline_${chainIdx + 1}`;

    lines.push(`// --- Pipeline Chain ${chainIdx + 1}: ${rootNode.data?.label || rootNode.type} ---`);
    lines.push('');

    // 루트에서 BFS로 도달 가능한 노드들을 위상 정렬 순서로 수집
    const chainNodes = collectChain(rootNode.id, sortedNodes, validEdges);

    let currentPipelineVar: string | null = null;
    const pipelineLines: string[] = [];

    chainNodes.forEach(node => {
      if (processedNodeIds.has(node.id)) return;
      processedNodeIds.add(node.id);

      const varName = nodeVarMap.get(node.id) || node.id;
      const mapper  = NODE_MAPPINGS[node.type] || null;

      // 업스트림 변수 목록 (join 등 다중 입력 처리용)
      const upstreamVarNames = validEdges
        .filter(e => e.target === node.id)
        .map(e => nodeVarMap.get(e.source))
        .filter((v): v is string => Boolean(v));

      const result = mapper
        ? mapper(node, varName, upstreamVarNames)
        : getFallbackMapping(node);

      if (result.type === 'source') {
        // fileInput 등 소스 노드 → type 블록 + load 문을 최상단에 출력
        result.lines.forEach(l => lines.push(l));
        lines.push('');
        currentPipelineVar = varName;
      } else if (result.type === 'pipeline' || result.type === 'terminal') {
        // 파이프라인 스텝 → 들여쓰기하여 누적
        result.lines.forEach(l => pipelineLines.push('  ' + l));
      }
    });

    // 파이프라인 스텝이 있으면 하나의 파이프라인 표현식으로 조합:
    //   v result_fileInput = fileInput
    //     |> filter(...)
    //     |> groupBy(...)
    //     |> mean(...)
    if (pipelineLines.length > 0 && currentPipelineVar) {
      lines.push(`v result_${chainVarName} = ${currentPipelineVar}`);
      pipelineLines.forEach(pl => lines.push(pl));
      lines.push('');
    } else if (pipelineLines.length > 0) {
      lines.push('// WARNING: 소스 노드 없이 파이프라인 스텝만 있음');
      pipelineLines.forEach(pl => lines.push(pl));
      lines.push('');
    }
  });

  // 연결되지 않은 고립 노드 처리
  const isolatedNodes = validNodes.filter(n => !processedNodeIds.has(n.id));
  if (isolatedNodes.length > 0) {
    lines.push('// --- 연결되지 않은 노드 ---');
    isolatedNodes.forEach(node => {
      const varName = nodeVarMap.get(node.id) || node.id;
      const mapper  = NODE_MAPPINGS[node.type] || null;
      const result  = mapper ? mapper(node, varName, []) : getFallbackMapping(node);
      if (result.type === 'source') {
        result.lines.forEach(l => lines.push(l));
        lines.push('');
      } else {
        lines.push(`// [고립 노드] ${node.data?.label || node.type}`);
        result.lines.forEach(l => lines.push('// ' + l));
        lines.push('');
      }
    });
  }

  return lines.join('\n');
}

// ─────────────────────────────────────────────────────────────────────────────
// ── 사용 예시 (App.jsx에서 호출되는 방식)
// ─────────────────────────────────────────────────────────────────────────────
//
// import { transpileToX1zz } from './transpiler/x1zzTranspiler.js';
//
// // React Flow의 useNodes/useEdges 훅으로 현재 상태 가져오기
// const nodes = useNodes();
// const edges = useEdges();
//
// // 버튼 클릭 또는 실시간으로 DSL 코드 생성
// const dslCode = transpileToX1zz(nodes, edges);
//
// // 생성된 코드를 에디터에 표시하거나 x1zz CLI로 전달
// console.log(dslCode);
// // 또는 백엔드 API로 전송하여 x1zz run 실행
// await fetch('/api/run', { method: 'POST', body: JSON.stringify({ code: dslCode }) });
//
// ─── 실제 생성 결과 예시 ──────────────────────────────────────────────────────
//
// // ============================================
// // Generated by x1zzLang Visual IDE Transpiler
// // Nodes: 5  |  Edges: 4
// // Generated at: 2026-06-12T06:10:00.000Z
// // ============================================
//
// // --- Pipeline Chain 1: seoul_air_2026.csv ---
//
// type Schema_fileInput = {
//   측정소명: String,
//   측정일시: String,
//   PM10농도: Float,
//   PM25농도: Float,
// }
// v fileInput = load("seoul_air_2026.csv") :: Schema_fileInput
//
// v result_fileInput = fileInput
//   |> filter(col("PM10농도") > 30)
//   |> groupBy("측정소명")
//   |> mean("PM10농도")
//   |> chart { type: "bar", x: "측정소명", y: "PM10농도", title: "지역별 PM10 평균" }
