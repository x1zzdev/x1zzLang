/*
==================================================
원본 파일
x1zz-compiler/src/runtime.rs  (apply_dynamic_bridge, execute_var_decl 내 파이프라인 연산 매핑 부분)

핵심 기능
Dynamic Bridge — AST PipelineOp → Polars LazyFrame 변환 (런타임 실행 엔진)

설명
파서가 생성한 AST의 PipelineOp 열거형을 실제 Polars LazyFrame 연산으로 변환한다.
컴파일 결과물(AST)이 실제 데이터 처리 엔진(Polars)으로 연결되는 핵심 브리지다.

역할:
  1. apply_dynamic_bridge()  — CSV 헤더명 ↔ 스키마 필드명 자동 매핑 (rename)
  2. to_polars_expr()        — AST Expr → polars::prelude::Expr 변환
  3. execute_var_decl()      — PipelineOp 배열을 순서대로 LazyFrame에 적용

전체 실행 체인:
  DSL 소스 → Lexer → Parser → AST → [apply_dynamic_bridge] → LazyFrame → collect → DataFrame

지원 연산 매핑:
  PipelineOp::Filter      → lf.filter(to_polars_expr(...))
  PipelineOp::GroupBy     → pending_group_by 저장 (다음 집계 연산과 쌍으로 처리)
  PipelineOp::Mean        → lf.group_by([...]).agg([col.mean()]) 또는 lf.select([col.mean()])
  PipelineOp::Sum         → lf.group_by([...]).agg([col.sum()])
  PipelineOp::Join        → lf.join(other_lf, left_keys, right_keys, JoinArgs)
  PipelineOp::OrderBy     → lf.sort([col], SortMultipleOptions)
  PipelineOp::Take        → lf.limit(n)
  PipelineOp::DropNull    → lf.filter(col.is_not_null())
  PipelineOp::FillNull    → lf.with_columns([col.fill_null(lit)])
  PipelineOp::WithColumn  → lf.with_columns([expr.alias("name")])
  PipelineOp::Cast        → lf.with_columns([col.cast(DataType)])
  PipelineOp::Replace     → lf.with_columns([col.str().replace_all(lit, lit, true)])
==================================================
*/

use std::collections::HashMap;

// ─────────────────────────────────────────────────────────────────────────────
// ── apply_dynamic_bridge — CSV 헤더 ↔ 스키마 필드명 자동 매핑 ──────────────────
// ─────────────────────────────────────────────────────────────────────────────

/// CSV 헤더와 스키마 필드명이 다를 때 자동으로 rename하여 브리지한다.
///
/// 예시:
///   CSV 헤더:       ["측정소명", "PM10농도", "PM25농도"]
///   스키마 필드명:  ["station", "pm10",     "pm25"    ]
///   → 순서 기반으로 position 매핑: 0번 컬럼을 station으로, 1번을 pm10으로 rename
///
/// 이 브리지 덕분에 사용자는 CSV 헤더가 영어인지 한국어인지 신경 쓰지 않아도 된다.
/// 선언된 스키마 이름(station, pm10)으로 일관성 있게 컬럼을 참조할 수 있다.
fn apply_dynamic_bridge(
    lf: polars::prelude::LazyFrame,
    csv_headers: &[String],
    schema_fields: &[StructField],
) -> polars::prelude::LazyFrame {
    // 매핑 대상 수: CSV 컬럼 수와 스키마 필드 수 중 작은 값으로 결정
    let map_count = csv_headers.len().min(schema_fields.len());

    // 위치 기반 매핑: CSV 헤더[i] → 스키마 필드명[i]
    let old_names: Vec<&str> = csv_headers[..map_count]
        .iter()
        .map(String::as_str)
        .collect();
    let new_names: Vec<&str> = schema_fields[..map_count]
        .iter()
        .map(|f| f.name.as_str())
        .collect();

    // 이름이 다른 것만 필터링 (불필요한 rename 방지)
    let (rename_old, rename_new): (Vec<&str>, Vec<&str>) = old_names
        .iter()
        .zip(new_names.iter())
        .filter(|(o, n)| o != n) // 이름이 같으면 rename 불필요
        .map(|(o, n)| (*o, *n))
        .unzip();

    if rename_old.is_empty() {
        lf // rename할 것이 없으면 원본 반환
    } else {
        // Polars LazyFrame.rename(old_names, new_names) 수행
        lf.rename(rename_old, rename_new, false)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ── to_polars_expr — AST Expr → Polars Expr 변환 ─────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/// AST의 Expr 노드를 Polars 실행 가능한 표현식으로 재귀적으로 변환한다.
///
/// 변환 예시:
///   Expr::BinOp { lhs: Ident("pm10"), op: Gt, rhs: FloatLit(30.0) }
///   → polars::col("pm10").gt(lit(30.0f64))
///
///   Expr::BinOp { lhs: Ident("a"), op: Add, rhs: Ident("b") }
///   → polars::col("a") + polars::col("b")
fn to_polars_expr(expr: &Expr) -> polars::prelude::Expr {
    use polars::prelude::{col, lit};
    match expr {
        // 컬럼 참조: col("pm10") → polars::col("pm10")
        Expr::Ident(s)      => col(s.as_str()),
        // 리터럴 값
        Expr::IntLit(n)     => lit(*n),
        Expr::FloatLit(f)   => lit(*f),
        Expr::StringLit(s)  => lit(s.clone()),
        Expr::BoolLit(b)    => lit(*b),
        // 이항 연산식: 재귀적으로 lhs, rhs를 변환한 후 연산자 적용
        Expr::BinOp { lhs, op, rhs } => {
            let l = to_polars_expr(lhs);
            let r = to_polars_expr(rhs);
            match op {
                // 비교 연산자 → Polars 비교 메서드
                BinOpKind::Eq    => l.eq(r),
                BinOpKind::NotEq => l.neq(r),
                BinOpKind::Lt    => l.lt(r),
                BinOpKind::Gt    => l.gt(r),
                BinOpKind::LtEq  => l.lt_eq(r),
                BinOpKind::GtEq  => l.gt_eq(r),
                // 산술 연산자 → Polars 연산자 오버로딩 ()
                BinOpKind::Add   => l + r,
                BinOpKind::Sub   => l - r,
                BinOpKind::Mul   => l * r,
                BinOpKind::Div   => l / r,
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ── execute_var_decl — 파이프라인 연산 순차 적용 (핵심 브리지 루프) ───────────────
// (발췌 — 파이프라인 연산 매핑 부분)
// ─────────────────────────────────────────────────────────────────────────────

/// AST의 PipelineOp 배열을 LazyFrame에 순서대로 적용한다.
///
/// GroupBy 처리 특이사항:
///   GroupBy 연산이 오면 group_col을 pending_group_by에 저장해두고,
///   바로 다음에 오는 집계 연산(Sum/Mean/Min/Max/Count(Some))에서
///   group_by([col]).agg([agg_expr]) 형태로 한번에 처리한다.
///
///   예: |> groupBy("station") |> mean("pm10")
///       → lf.group_by([col("station")]).agg([col("pm10").mean()])
fn apply_pipeline_ops(
    mut lf: polars::prelude::LazyFrame,
    ops: &[PipelineOp],
    symbol_table: &HashMap<String, polars::frame::DataFrame>,
) -> Result<polars::prelude::LazyFrame, Box<dyn std::error::Error>> {
    use polars::prelude::{JoinArgs, SortMultipleOptions, col, lit};

    // GroupBy 연산이 왔을 때 group 컬럼을 임시 저장
    let mut pending_group_by: Option<String> = None;

    for op in ops {
        match op {
            // ── Filter — 조건식 기반 행 필터링 ───────────────────────────────
            // |> filter(col("pm10") > 30.0)
            // → lf.filter(to_polars_expr(expr))
            PipelineOp::Filter(expr) => {
                lf = lf.filter(to_polars_expr(expr));
            }

            // ── Select — 컬럼 선택 ────────────────────────────────────────────
            // |> select(["station", "pm10"])
            // → lf.select([col("station"), col("pm10")])
            PipelineOp::Select(cols) => {
                let exprs: Vec<polars::prelude::Expr> =
                    cols.iter().map(|c| col(c.as_str())).collect();
                lf = lf.select(exprs);
            }

            // ── GroupBy + 집계 연산 연계 ──────────────────────────────────────
            // GroupBy 자체는 LazyFrame을 바꾸지 않고 pending_group_by에 저장만 함.
            // 뒤따르는 Sum/Mean/Min/Max/Count(Some)에서 한번에 group_by().agg() 처리
            PipelineOp::GroupBy(group_col) => {
                pending_group_by = Some(group_col.clone());
            }

            // ── Mean — 평균 집계 ──────────────────────────────────────────────
            // GroupBy와 쌍: lf.group_by([col(g)]).agg([col(a).mean()])
            // 단독:         lf.select([col(a).mean()])
            PipelineOp::Mean(agg_col) => {
                if let Some(group_col) = pending_group_by.take() {
                    lf = lf
                        .group_by([col(group_col.as_str())])
                        .agg([col(agg_col.as_str()).mean()]);
                } else {
                    lf = lf.select([col(agg_col.as_str()).mean()]);
                }
            }

            // ── Sum — 합계 집계 ───────────────────────────────────────────────
            PipelineOp::Sum(agg_col) => {
                if let Some(group_col) = pending_group_by.take() {
                    lf = lf
                        .group_by([col(group_col.as_str())])
                        .agg([col(agg_col.as_str()).sum()]);
                } else {
                    lf = lf.select([col(agg_col.as_str()).sum()]);
                }
            }

            // ── Min / Max ─────────────────────────────────────────────────────
            PipelineOp::Min(agg_col) => {
                if let Some(group_col) = pending_group_by.take() {
                    lf = lf.group_by([col(group_col.as_str())]).agg([col(agg_col.as_str()).min()]);
                } else {
                    lf = lf.select([col(agg_col.as_str()).min()]);
                }
            }
            PipelineOp::Max(agg_col) => {
                if let Some(group_col) = pending_group_by.take() {
                    lf = lf.group_by([col(group_col.as_str())]).agg([col(agg_col.as_str()).max()]);
                } else {
                    lf = lf.select([col(agg_col.as_str()).max()]);
                }
            }

            // ── OrderBy — 정렬 ────────────────────────────────────────────────
            // |> orderBy("pm10", desc: true)
            // → lf.sort(["pm10"], SortMultipleOptions::default().with_order_descending(true))
            PipelineOp::OrderBy { col: sort_col, desc } => {
                let sort_opts = SortMultipleOptions::default().with_order_descending(*desc);
                lf = lf.sort([sort_col.as_str()], sort_opts);
            }

            // ── Take — 상위 N행 슬라이싱 ──────────────────────────────────────
            // |> take(10) → lf.limit(10)
            PipelineOp::Take(n) => {
                lf = lf.limit(*n as u32);
            }

            // ── DropNull — null 행 제거 ────────────────────────────────────────
            // |> dropNull("pm10") → lf.filter(col("pm10").is_not_null())
            PipelineOp::DropNull(drop_col) => {
                lf = lf.filter(col(drop_col.as_str()).is_not_null());
            }

            // ── FillNull — null 값 채우기 ─────────────────────────────────────
            // |> fillNull("pm10", 0.0)
            // → lf.with_columns([col("pm10").fill_null(lit(0.0f64))])
            PipelineOp::FillNull { col: fill_col, value } => {
                let fill_lit: polars::prelude::Expr = match value {
                    FillNullValue::Int(n)   => lit(*n),
                    FillNullValue::Float(f) => lit(*f),
                    FillNullValue::Str(s)   => lit(s.clone()),
                };
                lf = lf.with_columns([col(fill_col.as_str()).fill_null(fill_lit)]);
            }

            // ── Join — 두 LazyFrame 조인 ──────────────────────────────────────
            // |> join(station_info, left_on: "station", right_on: "adm_name", how: "left")
            // → lf.join(other_lf, [col("station")], [col("adm_name")], JoinArgs::new(Left))
            PipelineOp::Join { other, left_on, right_on, how } => {
                match symbol_table.get(other.as_str()) {
                    Some(other_df) => {
                        let other_lf = other_df.clone().lazy();
                        let left_keys: Vec<polars::prelude::Expr> =
                            left_on.iter().map(|k| col(k.as_str())).collect();
                        let right_keys: Vec<polars::prelude::Expr> =
                            right_on.iter().map(|k| col(k.as_str())).collect();
                        let join_type = to_polars_join_type(how);
                        lf = lf.join(
                            other_lf,
                            left_keys,
                            right_keys,
                            JoinArgs::new(join_type),
                        );
                    }
                    None => {
                        return Err(format!(
                            "런타임 에러: join() 대상 변수 '{}' 가 심볼 테이블에 없습니다.",
                            other
                        ).into());
                    }
                }
            }

            // ── WithColumn — 새 컬럼 추가/변환 ────────────────────────────────
            // |> withColumn("ratio", col("pm25") / col("pm10"))
            // → lf.with_columns([(col("pm25") / col("pm10")).alias("ratio")])
            PipelineOp::WithColumn { name: col_name, expr } => {
                let polars_expr = to_polars_expr(expr).alias(col_name.as_str());
                lf = lf.with_columns([polars_expr]);
            }

            // ── Cast — DSL-레벨 명시적 타입 캐스팅 ───────────────────────────
            // |> cast("pm10", "float") → lf.with_columns([col("pm10").cast(DataType::Float64)])
            PipelineOp::Cast { col: cast_col, to_type } => {
                use polars::prelude::DataType;
                let dtype = match to_type.as_str() {
                    "float" => DataType::Float64,
                    "int"   => DataType::Int64,
                    "str"   => DataType::String,
                    "bool"  => DataType::Boolean,
                    other => return Err(format!(
                        "cast() 에 알 수 없는 타입 '{}'. 지원: float/int/str/bool", other
                    ).into()),
                };
                lf = lf.with_columns([col(cast_col.as_str()).cast(dtype)]);
            }

            // ── Rename — 컬럼 이름 변경 ───────────────────────────────────────
            // |> rename("측정소명", "station")
            PipelineOp::Rename { old_name, new_name } => {
                lf = lf.rename(vec![old_name.as_str()], vec![new_name.as_str()], false);
            }

            // ── Replace — 문자열 치환 ─────────────────────────────────────────
            // |> replace("station", ".", "")
            // → lf.with_columns([col("station").str().replace_all(lit("."), lit(""), true)])
            PipelineOp::Replace { col: replace_col, from, to } => {
                lf = lf.with_columns([
                    col(replace_col.as_str())
                        .str()
                        .replace_all(lit(from.as_str()), lit(to.as_str()), true)
                        .alias(replace_col.as_str())
                ]);
            }

            // Count 처리 (단순화)
            PipelineOp::Count(None)          => { /* has_count_flag 처리 */ }
            PipelineOp::Count(Some(agg_col)) => {
                if let Some(group_col) = pending_group_by.take() {
                    lf = lf.group_by([col(group_col.as_str())])
                        .agg([col(agg_col.as_str()).count()]);
                } else {
                    lf = lf.select([col(agg_col.as_str()).count()]);
                }
            }

            // Chart는 별도의 ChartSpec 생성 + HTML 출력 로직 처리 (runtime.rs 참고)
            PipelineOp::Chart(_) => { /* runtime.rs의 build_chart_spec 참고 */ }
        }
    }

    Ok(lf)
}

// ─────────────────────────────────────────────────────────────────────────────
// ── JoinHow → Polars JoinType 변환 ────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/// x1zzLang JoinHow 열거형 → Polars JoinType 변환
fn to_polars_join_type(how: &JoinHow) -> polars::prelude::JoinType {
    use polars::prelude::JoinType;
    match how {
        JoinHow::Inner => JoinType::Inner,
        JoinHow::Left  => JoinType::Left,
        JoinHow::Outer => JoinType::Full,
        JoinHow::Cross => JoinType::Cross,
    }
}

// 타입 더미 (컴파일 목적 — 실제 정의는 ast.rs, runtime.rs에 있음)
struct StructField { name: String, field_type: String }
#[derive(Debug, Clone, PartialEq)]
enum Expr { Ident(String), StringLit(String), IntLit(i64), FloatLit(f64), BoolLit(bool), BinOp { lhs: Box<Expr>, op: BinOpKind, rhs: Box<Expr> } }
#[derive(Debug, Clone, PartialEq)]
enum BinOpKind { Eq, NotEq, Lt, Gt, LtEq, GtEq, Add, Sub, Mul, Div }
#[derive(Debug, Clone, PartialEq)]
enum JoinHow { Inner, Left, Outer, Cross }
enum FillNullValue { Int(i64), Float(f64), Str(String) }
enum PipelineOp {
    Filter(Expr), Select(Vec<String>), Count(Option<String>), GroupBy(String),
    Sum(String), Mean(String), Min(String), Max(String),
    OrderBy { col: String, desc: bool }, Take(i64), DropNull(String),
    FillNull { col: String, value: FillNullValue },
    Join { other: String, left_on: Vec<String>, right_on: Vec<String>, how: JoinHow },
    WithColumn { name: String, expr: Expr }, Cast { col: String, to_type: String },
    Rename { old_name: String, new_name: String }, Replace { col: String, from: String, to: String },
    Chart(()),
}
