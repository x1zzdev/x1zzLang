/*
==================================================
원본 파일
x1zz-compiler/src/runtime.rs  (validate_schema_types, load_csv_as_df, execute_var_decl 내 스키마 검증 흐름)

핵심 기능
Safe-Load 스키마 검증 (의사 컴파일 타임 오류 검출)

설명
사용자가 DSL에서 선언한 type 블록 (TypeDecl) 과
실제 CSV 파일의 컬럼·타입 정보를 비교하여,
실행 전(의사 컴파일 단계)에 오류를 조기 검출한다.

흐름:
  1. load_csv_as_df()      — CSV 파일을 Polars DataFrame으로 로드
  2. TypeRegistry 조회     — type 블록에서 선언된 스키마 필드 가져오기
  3. apply_schema_cast()   — 스키마 타입에 맞게 LazyFrame 컬럼 캐스팅
  4. validate_schema_types() — null 값/타입 불일치 조기 경고 출력

x1zzLang DSL 예시:
  type AirQuality {
      station: string,
      pm10: float,
      pm25: Option<float>,   // Option = nullable 허용
      date: string,
  }
  v air = load("seoul_air_2026.csv") :: AirQuality

위 코드에서 pm10이 null이면 실행 전에 경고 메시지가 출력된다.
실제 데이터 오류를 런타임 크래시 없이 미리 감지하는 것이 핵심이다.
==================================================
*/

use std::collections::HashMap;

// ─────────────────────────────────────────────────────────────────────────────
// ── CSV 로더 — 인코딩 자동 감지 + Dirty-data null 정규화 ──────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/// CSV 파일을 Polars DataFrame으로 로드한다.
///
/// 핵심 처리:
///  - UTF-8 BOM, EUC-KR(CP949) 자동 감지 및 UTF-8 변환
///  - 빈 문자열, "-", "점검중", "N/A" 등 더러운 값을 null로 정규화
///  - infer_schema_length=200: 충분한 행 수 기반 타입 추론
fn load_csv_as_df(file_path: &str) -> Result<polars::frame::DataFrame, Box<dyn std::error::Error>> {
    use polars::prelude::{CsvParseOptions, CsvReadOptions, NullValues, SerReader};
    use std::io::Cursor;

    // 파일을 바이트로 읽음 (인코딩 자동 처리를 위해 raw bytes 단계에서 처리)
    let raw_bytes = std::fs::read(file_path)
        .map_err(|e| format!("IO 에러: CSV 파일 읽기 실패 '{}' — {}", file_path, e))?;

    // UTF-8 → EUC-KR 순서로 디코딩 시도
    let utf8_string = match String::from_utf8(raw_bytes.clone()) {
        Ok(s) => s,
        Err(_) => {
            // UTF-8 실패 시 EUC-KR(한국 공공데이터 기본 인코딩)로 재시도
            use encoding_rs::EUC_KR;
            let (cow, _encoding_used, _had_errors) = EUC_KR.decode(&raw_bytes);
            cow.into_owned()
        }
    };

    // 한국 공공 데이터 CSV에서 자주 나타나는 Dirty 값을 null로 정규화
    // 이 처리 없이는 "점검중" 같은 값이 문자열로 남아 타입 캐스팅에 실패한다
    let null_vals = NullValues::AllColumns(vec![
        "".into(),
        " ".into(),
        "-".into(),
        "점검중".into(),
        "N/A".into(),
    ]);

    let cursor = Cursor::new(utf8_string.into_bytes());
    let df = CsvReadOptions::default()
        .with_infer_schema_length(Some(200))   // 200행 샘플로 타입 추론
        .with_parse_options(CsvParseOptions::default().with_null_values(Some(null_vals)))
        .into_reader_with_file_handle(cursor)
        .finish()?;

    Ok(df)
}

// ─────────────────────────────────────────────────────────────────────────────
// ── Schema-Based Type Cast — TypeDecl 스키마 기반 자동 타입 캐스팅 ─────────────
// ─────────────────────────────────────────────────────────────────────────────

/// TypeDecl 스키마 필드 정의를 기반으로 LazyFrame 컬럼을 명시적으로 캐스팅한다.
///
/// x1zzLang DSL 타입과 Polars DataType 매핑:
///   string / str → DataType::String
///   int          → DataType::Int64
///   float        → DataType::Float64
///   bool         → DataType::Boolean
///
/// Option<T> 래퍼는 무시하고 내부 타입으로 캐스팅한다.
/// (nullable 허용 여부는 validate_schema_types()에서 별도 검사)
fn apply_schema_cast(
    lf: polars::prelude::LazyFrame,
    schema_fields: &[StructField],
) -> polars::prelude::LazyFrame {
    use polars::prelude::{DataType, col};

    let cast_exprs: Vec<polars::prelude::Expr> = schema_fields
        .iter()
        .filter_map(|field| {
            // "Option<float>" → "float" 로 내부 타입 추출
            let inner_type = if field.field_type.starts_with("Option<") {
                field
                    .field_type
                    .trim_start_matches("Option<")
                    .trim_end_matches('>')
            } else {
                field.field_type.as_str()
            };

            // x1zzLang 타입 문자열 → Polars DataType 변환
            let dtype = match inner_type {
                "string" | "str" => Some(DataType::String),
                "int"            => Some(DataType::Int64),
                "float"          => Some(DataType::Float64),
                "bool"           => Some(DataType::Boolean),
                _                => None, // 알 수 없는 타입은 캐스팅 없이 그대로
            };

            // col("fieldName").cast(DataType).alias("fieldName") 표현식 생성
            dtype.map(|dt| col(field.name.as_str()).cast(dt).alias(field.name.as_str()))
        })
        .collect();

    if cast_exprs.is_empty() {
        lf
    } else {
        lf.with_columns(cast_exprs) // 한번에 모든 컬럼 캐스팅 (효율적 Single-pass)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ── validate_schema_types — 핵심 Safe-Load 검증 로직 ─────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/// TypeDecl 스키마와 실제 로드된 DataFrame을 비교하여 타입/null 위반을 경고한다.
///
/// 검사 항목:
///   1. 타입 존재 검사  — schema_fields에 선언된 컬럼이 DataFrame에 실제로 있는지
///   2. Option 필드 검사 — Option<T>로 선언되지 않은 필수 필드에 null이 있으면 경고
///
/// 이 함수는 경고만 출력하며 실행을 중단하지 않는다.
/// 강한 오류 모드는 향후 --strict 플래그로 확장 예정이다.
///
/// 예시 출력:
///   [x1zz WARN] Null 위반 [AirQuality]: 필수 필드 'pm10' (Float64) 에 null 3 개 발견
///   [x1zz WARN] 스키마 필드 'station' 를 DataFrame에서 찾을 수 없음
fn validate_schema_types(
    df: &polars::frame::DataFrame,
    schema_name: &str,
    schema_fields: &[StructField],
) {
    for field in schema_fields {
        // Option<T>인지 판별 — Option이면 null 허용
        let is_optional = field.field_type.starts_with("Option<");

        match df.column(&field.name) {
            Ok(series) => {
                let null_count = series.null_count();
                let dtype = series.dtype();

                // 필수 필드(non-Option)에 null이 있는 경우 — Safe-Load 검증 실패
                if null_count > 0 && !is_optional {
                    eprintln!(
                        "[x1zz WARN] Null 위반 [{}]: 필수 필드 '{}' ({:?}) 에 null {} 개 발견",
                        schema_name, field.name, dtype, null_count
                    );
                }
            }
            Err(_) => {
                // 컬럼 자체가 DataFrame에 없는 경우 — 스키마 필드명 불일치
                eprintln!(
                    "[x1zz WARN] 스키마 필드 '{}' 를 DataFrame에서 찾을 수 없음",
                    field.name
                );
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ── execute_var_decl — Safe-Load 흐름을 통합하는 파이프라인 실행 진입점 ─────────
// (발췌 — 소스 결정 + 타입 검증 부분만)
// ─────────────────────────────────────────────────────────────────────────────

/// 단일 VarDecl 파이프라인 실행.
/// Load 소스를 처리할 때 TypeRegistry에서 스키마를 찾아 Safe-Load 검증을 수행한다.
fn execute_var_decl_excerpt(
    source: &PipelineSource,
    symbol_table: &HashMap<String, polars::frame::DataFrame>,
    type_registry: &HashMap<String, Vec<StructField>>,
) -> Result<polars::prelude::LazyFrame, Box<dyn std::error::Error>> {
    use polars::prelude::IntoLazy;

    match source {
        PipelineSource::Load { file_path, schema_name } => {
            // 1) CSV → DataFrame 로드 (인코딩 자동 처리 + null 정규화)
            let df_raw = load_csv_as_df(file_path)?;

            let csv_headers: Vec<String> = df_raw
                .get_column_names()
                .iter()
                .map(|s| s.to_string())
                .collect();

            // 2) TypeRegistry에서 선언된 스키마 조회
            //    type AirQuality { ... } → type_registry["AirQuality"]
            let schema_fields = type_registry.get(schema_name.as_str()).cloned();
            let lf_raw = df_raw.lazy();

            let lf_bridged = if let Some(ref fields) = schema_fields {
                // 3) Dynamic Bridge: CSV 헤더 → 스키마 필드명 rename
                let lf_renamed = apply_dynamic_bridge(lf_raw, &csv_headers, fields);
                // 4) TypeDecl 스키마 기반 자동 타입 캐스팅
                apply_schema_cast(lf_renamed, fields)
            } else {
                lf_raw
            };

            // 5) Safe-Load 검증: null/타입 불일치 경고
            //    (LazyFrame → collect → DataFrame 으로 검증 후 다시 lazy로 환원)
            if let Some(ref fields) = schema_fields {
                let df_check = lf_bridged.clone().collect()?;
                validate_schema_types(&df_check, schema_name, fields);
                Ok(df_check.lazy())
            } else {
                Ok(lf_bridged)
            }
        }

        PipelineSource::VarRef(src_var) => {
            // 기존 변수 참조 — TypeRegistry 검증 없이 바로 사용
            match symbol_table.get(src_var.as_str()) {
                Some(df) => Ok(df.clone().lazy()),
                None => Err(format!(
                    "변수 에러: 미선언 변수 '{}' 참조.", src_var
                ).into()),
            }
        }
    }
}

// 타입 더미 (컴파일 목적 — 실제 정의는 ast.rs, runtime.rs에 있음)
struct StructField { name: String, field_type: String }
enum PipelineSource {
    Load { file_path: String, schema_name: String },
    VarRef(String),
}
fn apply_dynamic_bridge(lf: polars::prelude::LazyFrame, _: &[String], _: &[StructField]) -> polars::prelude::LazyFrame { lf }
