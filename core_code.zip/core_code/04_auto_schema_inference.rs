/*
==================================================
원본 파일
src/schema.rs

핵심 기능
Auto Schema Inference — CSV 파일을 스캔하여 x1zzLang 타입 정의를 자동 생성

설명
사용자가 타입을 직접 정의하지 않아도,
`x1zz import data.csv` 명령 하나로 CSV 파일을 분석하여
x1zzLang의 type 블록과 load 문을 자동으로 생성한다.

예시:
  $ x1zz import seoul_air_2026.csv

출력 결과 (main.xzz에 자동 추가됨):
  type SeoulAir2026 = {
      측정소명: string,
      측정일시: string,
      PM10농도: Option<float>,
      PM25농도: Option<float>,
      O3농도:   float,
  };

  v air = load("seoul_air_2026.csv") :: SeoulAir2026

타입 추론 규칙:
  - "true" / "false" 문자열 → bool
  - 정수 파싱 성공         → int
  - 소수점 파싱 성공       → float
  - 그 외                  → string
  - 빈 값이 있는 컬럼      → Option<T>  (nullable)

최대 100행 샘플로 타입을 추론하여 성능을 보장한다.
타입 승격 규칙으로 int + float = float 등 자연스럽게 통합된다.
==================================================
*/

use anyhow::{Context, Result};
use std::fs;
use std::io::Read;

// ─────────────────────────────────────────────────────────────────────────────
// ── 내부 타입 열거형 ─────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/// 컬럼의 추론된 타입
#[derive(Debug, Clone, PartialEq)]
enum ColType {
    Bool,
    Int,
    Float,
    String,
}

// ─────────────────────────────────────────────────────────────────────────────
// ── 단일 셀 타입 추론 ────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/// 단일 셀 값 문자열에서 x1zzLang 타입을 추론한다.
///
/// 판별 순서:
///   1. "true" / "false" (대소문자 무관) → Bool
///   2. 정수 파싱 가능                    → Int
///   3. 부동소수 파싱 가능               → Float
///   4. 그 외                            → String
///
/// 예시:
///   "true"   → Bool
///   "42"     → Int
///   "3.14"   → Float
///   "서울시" → String
fn infer_type(value: &str) -> ColType {
    let trimmed = value.trim();
    // 불리언 체크 (대소문자 무관)
    match trimmed.to_lowercase().as_str() {
        "true" | "false" => return ColType::Bool,
        _ => {}
    }
    // 정수 파싱
    if trimmed.parse::<i64>().is_ok() {
        return ColType::Int;
    }
    // 부동소수 파싱
    if trimmed.parse::<f64>().is_ok() {
        return ColType::Float;
    }
    ColType::String
}

// ─────────────────────────────────────────────────────────────────────────────
// ── 타입 승격 규칙 (Type Promotion) ─────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/// 두 타입을 병합한다 (타입 승격 규칙).
///
/// 같은 타입끼리는 그대로 유지.
/// 호환 가능한 숫자 타입은 상위 타입으로 승격:
///   Int  + Float = Float  (정수와 소수가 혼재 → Float로 통일)
/// 호환 불가한 타입 조합은 String으로 fallback:
///   Bool + Int   = String  (의미가 모호하므로 문자열로 처리)
///   Bool + Float = String
fn merge_type(a: ColType, b: ColType) -> ColType {
    use ColType::*;
    match (a, b) {
        (Bool,   Bool)   => Bool,
        (Int,    Int)    => Int,
        (Float,  Float)  => Float,
        (String, String) => String,
        (Int,    Float)  | (Float, Int)   => Float,  // 숫자 타입 승격
        (Bool,   Int)    | (Int,   Bool)  => String, // 불명확 → String
        (Bool,   Float)  | (Float, Bool)  => String, // 불명확 → String
        _                                 => String, // 그 외 → String
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ── 파일 경로 → PascalCase 타입 이름 변환 ────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/// 파일 경로에서 PascalCase 타입 이름을 생성한다.
///
/// 규칙: 파일명(확장자 제외)의 각 세그먼트 첫 글자를 대문자로 변환
///
/// 예시:
///   "data/seoul_air.csv"     → "SeoulAir"
///   "weather_data.csv"       → "WeatherData"
///   "population.csv"         → "Population"
///   "seoul_air_2026.csv"     → "SeoulAir2026"
fn filename_to_type_name(path: &str) -> String {
    let stem = std::path::Path::new(path)
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("Unknown");

    // 언더스코어(_) 또는 하이픈(-)으로 분리하여 각 세그먼트 첫 글자 대문자화
    stem.split(|c: char| c == '_' || c == '-')
        .filter(|s| !s.is_empty())
        .map(|seg| {
            let mut chars = seg.chars();
            match chars.next() {
                None        => String::new(),
                Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
            }
        })
        .collect::<String>()
}

/// 파일 경로에서 변수 이름을 생성한다.
///
/// 규칙: 마지막 언더스코어 이후 세그먼트 (단, 숫자뿐이거나 너무 짧으면 앞 세그먼트)
///
/// 예시:
///   "seoul_air.csv"     → "air"
///   "weather_data.csv"  → "data"
///   "population.csv"    → "population"
fn filename_to_var_name(path: &str) -> String {
    let stem = std::path::Path::new(path)
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("data");

    let segments: Vec<&str> = stem.split('_').collect();
    if segments.len() >= 2 {
        let last = *segments.last().unwrap_or(&stem);
        // 마지막 세그먼트가 의미있는 단어면 사용, 숫자거나 너무 짧으면 앞 세그먼트
        if last.len() >= 2 && last.parse::<u64>().is_err() {
            last.to_lowercase()
        } else if segments.len() >= 2 {
            segments[segments.len() - 2].to_lowercase()
        } else {
            stem.to_lowercase()
        }
    } else {
        stem.to_lowercase()
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ── 핵심 함수: infer_csv_schema — CSV 스캔 → x1zzLang 코드 생성 ──────────────
// ─────────────────────────────────────────────────────────────────────────────

/// CSV 파일을 읽어 x1zzLang 타입 정의 블록과 load 문을 자동 생성한다.
///
/// 처리 단계:
///   1. 파일 읽기 (바이트 단위)
///   2. 인코딩 감지: UTF-8 BOM → EUC-KR → UTF-8 순서로 시도
///   3. CSV 헤더 파싱
///   4. 최대 100행 샘플로 각 컬럼 타입 추론 + nullable 감지
///   5. x1zzLang type 블록 + load 문 코드 생성
///
/// 생성 결과 예시 (seoul_air_2026.csv로 실행 시):
///   type SeoulAir2026 = {
///       측정소명: string,
///       측정일시: string,
///       PM10농도: Option<float>,
///       PM25농도: Option<float>,
///   };
///
///   v air = load("seoul_air_2026.csv") :: SeoulAir2026
pub fn infer_csv_schema(csv_path: &str) -> Result<String> {
    // ── 1. 파일 읽기 ─────────────────────────────────────────────────────────
    let mut file = fs::File::open(csv_path)
        .with_context(|| format!("CSV 파일 '{}' 을 열 수 없습니다.", csv_path))?;
    let mut raw_bytes = Vec::new();
    file.read_to_end(&mut raw_bytes)
        .with_context(|| format!("CSV 파일 '{}' 읽기 실패", csv_path))?;

    // ── 2. 인코딩 감지 및 UTF-8 변환 ─────────────────────────────────────────
    let content = if raw_bytes.starts_with(&[0xEF, 0xBB, 0xBF]) {
        // UTF-8 BOM이 있으면 BOM(3바이트) 제거 후 UTF-8로 처리
        String::from_utf8(raw_bytes[3..].to_vec())
            .map_err(|e| anyhow::anyhow!("UTF-8 디코딩 실패: {}", e))?
    } else {
        // EUC-KR(한국 공공데이터 기본 인코딩) 디코딩 시도
        let (cow, _, had_errors) = encoding_rs::EUC_KR.decode(&raw_bytes);
        if had_errors {
            // EUC-KR 실패 시 UTF-8으로 fallback
            String::from_utf8(raw_bytes)
                .map_err(|e| anyhow::anyhow!("UTF-8 디코딩도 실패: {}", e))?
        } else {
            cow.into_owned()
        }
    };

    // ── 3. CSV 헤더 파싱 ─────────────────────────────────────────────────────
    let mut rdr = csv::ReaderBuilder::new()
        .has_headers(true)
        .from_reader(content.as_bytes());

    let headers: Vec<String> = rdr
        .headers()
        .with_context(|| "CSV 헤더를 읽는 데 실패했습니다.")?
        .iter()
        .map(|h| h.to_owned())
        .collect();

    let col_count = headers.len();

    // ── 4. 타입 추론 — 최대 100행 샘플링 ────────────────────────────────────
    // 각 컬럼별 추론된 타입과 nullable 여부 초기화
    let mut col_types: Vec<Option<ColType>> = vec![None; col_count];
    let mut col_nullable: Vec<bool> = vec![false; col_count];

    for result in rdr.records().take(100) {
        let record = result.with_context(|| "CSV 레코드 읽기 실패")?;

        for (i, field) in record.iter().enumerate() {
            if i >= col_count { break; }
            let trimmed = field.trim();

            if trimmed.is_empty() {
                // 빈 값 → nullable 플래그 설정
                col_nullable[i] = true;
                continue;
            }

            // 이미 추론된 타입과 현재 셀의 타입을 merge_type으로 병합
            let inferred = infer_type(trimmed);
            col_types[i] = Some(match col_types[i].take() {
                None           => inferred,                           // 첫 번째 값: 그대로
                Some(existing) => merge_type(existing, inferred),     // 이후 값: 타입 병합
            });
        }
    }

    // 한 번도 값이 채워지지 않은 컬럼(모두 빈 값) → String으로 기본 처리
    let col_types: Vec<ColType> = col_types
        .into_iter()
        .map(|t| t.unwrap_or(ColType::String))
        .collect();

    // ── 5. x1zzLang 코드 생성 ────────────────────────────────────────────────
    let type_name = filename_to_type_name(csv_path); // "SeoulAir2026"
    let var_name  = filename_to_var_name(csv_path);  // "air"

    let mut output = String::new();

    // type 블록 생성
    output.push_str(&format!("type {} = {{\n", type_name));

    for (i, header) in headers.iter().enumerate() {
        // 기본 타입 문자열
        let base = match &col_types[i] {
            ColType::Bool   => "bool",
            ColType::Int    => "int",
            ColType::Float  => "float",
            ColType::String => "string",
        };
        // nullable 컬럼은 Option<T>로 래핑
        let type_str = if col_nullable[i] {
            format!("Option<{}>", base)
        } else {
            base.to_owned()
        };
        let comma = if i + 1 < col_count { "," } else { "" };
        output.push_str(&format!("    {}: {}{}\n", header, type_str, comma));
    }

    output.push_str("};\n");
    output.push('\n');
    // load 문 생성
    output.push_str(&format!(
        "v {} = load(\"{}\") :: {}",
        var_name, csv_path, type_name
    ));

    Ok(output)
}

// ─────────────────────────────────────────────────────────────────────────────
// ── import_csv — CLI "x1zz import" 명령 처리 ────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

/// `x1zz import <file.csv>` 명령을 처리한다.
///
/// 1. infer_csv_schema()로 타입 정의와 load 문을 생성
/// 2. 현재 프로젝트의 main.xzz에 생성된 코드를 추가
/// 3. 터미널에 생성된 코드를 출력
///
/// 사용 예:
///   $ x1zz import data/seoul_air_2026.csv
///   ✅  'data/seoul_air_2026.csv' 스키마 추론 완료 → main.xzz 에 추가되었습니다.
///
///   type SeoulAir2026 = {
///       ...
///   }
///   v air = load("data/seoul_air_2026.csv") :: SeoulAir2026
pub fn import_csv(file: &str) -> Result<()> {
    // 스키마 추론 + 코드 생성
    let generated = infer_csv_schema(file)?;

    // main.xzz 기존 내용 읽기 (없으면 빈 파일로 처리)
    let current = if std::path::Path::new("main.xzz").exists() {
        fs::read_to_string("main.xzz").with_context(|| "main.xzz 읽기 실패")?
    } else {
        String::new()
    };

    // 기존 내용 끝에 빈 줄을 추가하고 생성된 코드를 이어붙임
    let updated = format!("{}\n\n{}\n", current.trim_end(), generated);

    fs::write("main.xzz", &updated).with_context(|| "main.xzz 쓰기 실패")?;

    // 성공 메시지 출력
    println!(
        "✅  '{}' 스키마 추론 완료 → main.xzz 에 추가되었습니다.",
        file
    );
    println!();
    println!("{}", generated);

    Ok(())
}

// ─────────────────────────────────────────────────────────────────────────────
// ── 사용 예시 (main.rs에서 호출되는 방식)
// ─────────────────────────────────────────────────────────────────────────────
//
// // CLI 처리 (src/main.rs)
// match cli.command {
//     Commands::Import { file } => {
//         schema::import_csv(&file)?;
//     }
//     ...
// }
//
// 결과물 예시 (실제 seoul_air_2026.csv 스캔 결과):
//
//   type SeoulAir2026 = {
//       측정소코드: int,
//       측정소명: string,
//       측정일시: string,
//       SO2농도: Option<float>,
//       CO농도: Option<float>,
//       O3농도: Option<float>,
//       NO2농도: Option<float>,
//       PM10농도: Option<float>,
//       PM25농도: Option<float>,
//   };
//
//   v air = load("seoul_air_2026.csv") :: SeoulAir2026
